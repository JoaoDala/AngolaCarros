#!/bin/bash

ARQUIVO="historico_vendas.txt"
BACKUP_DIR="/media/danilo/backup"
BACKUP_ZIP="backup_$(date +%F_%H%M).zip"

# Verifica se a partição está montada
if [[ ! -d "$BACKUP_DIR" ]]; then
    dialog --title "Erro" --msgbox "A partição /media/danilo/backup não está montada ou acessível." 7 60
    exit 1
fi

# Verifica se o arquivo existe
if [[ -f "$ARQUIVO" ]]; then
    zip -q "$BACKUP_DIR/$BACKUP_ZIP" "$ARQUIVO"
    dialog --title "Backup" --msgbox "Backup criado com sucesso em:\n$BACKUP_DIR/$BACKUP_ZIP" 8 60
else
    dialog --title "Erro" --msgbox "Arquivo de histórico não encontrado!" 6 40
fi

